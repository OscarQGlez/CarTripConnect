INSERT INTO `CarTripConnectDB`.`users` (`id`,`name`,`email`,`password`,`address`,`phone`,`usertype`,`genre`,`age`,`createdAt`,`updatedAt`) VALUES ('1','Jane Doe','janedoe@example.com','secure123','456 Elm Avenue','555-5678','user','female','25','2023-05-24 12:02:35','2023-05-24 12:02:35');
INSERT INTO `CarTripConnectDB`.`users` (`id`,`name`,`email`,`password`,`address`,`phone`,`usertype`,`genre`,`age`,`createdAt`,`updatedAt`) VALUES ('4','John Smith','johnsmith@example.com','p@ssw0rd','123 Main Street','555-1234','user','male','30','2023-05-24 12:04:46','2023-05-24 12:04:46');
INSERT INTO `CarTripConnectDB`.`users` (`id`,`name`,`email`,`password`,`address`,`phone`,`usertype`,`genre`,`age`,`createdAt`,`updatedAt`) VALUES ('5','pepe','pepe@gmail.com','12345678','calle margarita,4','555555555','driver','masculino','23','2023-05-24 12:04:50','2023-05-24 12:04:50');



INSERT INTO `CarTripConnectDB`.`users` (`id`,`name`,`email`,`password`,`address`,`phone`,`usertype`,`genre`,`age`,`createdAt`,`updatedAt`) 
VALUES ('1','Jane Doe','janedoe@example.com','secure123','456 Elm Avenue','555-5678','user','female','25','2023-05-24 12:02:35','2023-05-24 12:02:35');
('4','John Smith','johnsmith@example.com','p@ssw0rd','123 Main Street','555-1234','user','male','30','2023-05-24 12:04:46','2023-05-24 12:04:46'),
('5','pepe','pepe@gmail.com','12345678','calle margarita,4','555555555','driver','masculino','23','2023-05-24 12:04:50','2023-05-24 12:04:50');
